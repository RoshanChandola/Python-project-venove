required things to run this project

1. Introduction
This documentation provides a comprehensive guide for setting up and running the Employee Activity Tracking Project. The project tracks employee activity by taking periodic screenshots and logging activity details.

2. System Requirements
To run the project, ensure that your system meets the following requirements:

Python 3.7 or higher
pip (Python package installer)
A code editor or IDE (e.g., Visual Studio Code, PyCharm)
3. Project Structure
The project should have the following directory structure:

bash
Copy code
/employee_activity_agent     # Main project folder (root)
    /config                  # Config files folder
    /logs                    # Logs folder
    /screenshots             # Screenshots folder
    /src                     # Source code folder
        activity_tracker.py
        screenshot_manager.py
        config_manager.py
        time_zone_manager.py
        main.py              # The main script
    requirements.txt         # Save it here, in the main folder
4. Installation Instructions

Install Python: Download and install Python from the official website (https://www.python.org/downloads/).
Set Up Virtual Environment:
Open the terminal or command prompt.
Navigate to the project folder: cd path_to_your_project/employee_activity_agent
Create a virtual environment: python -m venv venv
Activate the virtual environment:
On Windows: venv\\Scripts\\activate
On macOS/Linux: source venv/bin/activate

Install Required Packages:

Run the following command to install the necessary 

packages: pip install -r requirements.txt
under this file:-psutil
pyautogui
pytz


5. Running the Project
To run the project, execute the following command in the terminal: python src/main.py
This will start the employee activity tracking process.

6. Stopping the Project
To stop the running project, use the keyboard shortcut:

Press Ctrl + C in the terminal.

This will interrupt the process and stop the script.

7. Conclusion
This documentation provides the necessary steps to set up and run the Employee Activity Tracking Project. If you encounter any issues, please consult the project's source code or seek further assistance.


there was some problem due to that i was not able to upload this on any cloud platform
