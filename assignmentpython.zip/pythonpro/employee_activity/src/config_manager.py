import json

class ConfigManager:
    def __init__(self, config_file="../config/config.json"):
        self.config_file = config_file
        self.config_data = None
        self.load_config()

    def load_config(self):
        with open(self.config_file, 'r') as file:
            self.config_data = json.load(file)

    def get_config(self, key):
        return self.config_data.get(key)
