from activity_tracker import ActivityTracker
from screenshot_manager import ScreenshotManager
from config_manager import ConfigManager
from time_zone_manager import TimeZoneManager
import time

def main():
    # Load config
    config = ConfigManager()
    screenshot_interval = config.get_config("screenshot_interval")
    time_zone = config.get_config("time_zone")

    # Initialize components
    activity_tracker = ActivityTracker()
    screenshot_manager = ScreenshotManager(interval=screenshot_interval)
    time_zone_manager = TimeZoneManager(time_zone=time_zone)

    print(f"Tracking started in time zone: {time_zone_manager.get_local_time()}")

    # Run activity tracking and screenshots
    while True:
        activity_tracker.track_activity()
        screenshot_manager.take_screenshot()
        time.sleep(10)  # Adjust based on desired check frequency

if __name__ == "__main__":
    main()
