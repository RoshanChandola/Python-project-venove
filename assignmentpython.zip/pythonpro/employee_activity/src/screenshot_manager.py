import time
import pyautogui
import os
from datetime import datetime

class ScreenshotManager:
    def __init__(self, interval=300):
        self.interval = interval  # Default interval is 5 minutes

    def take_screenshot(self):
        screenshot_folder = "../screenshots"
        if not os.path.exists(screenshot_folder):
            os.makedirs(screenshot_folder)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"screenshot_{timestamp}.png"
        file_path = os.path.join(screenshot_folder, file_name)
        pyautogui.screenshot(file_path)

    def run(self):
        while True:
            self.take_screenshot()
            time.sleep(self.interval)
