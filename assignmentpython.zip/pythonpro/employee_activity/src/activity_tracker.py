import time
import psutil
from datetime import datetime

class ActivityTracker:
    def __init__(self):
        self.active_window = None
        self.idle_time_start = None
        self.idle_time_limit = 300  # 5 minutes idle time

    def get_active_window(self):
        try:
            active_app = psutil.Process(psutil.Process().pid).name()
            return active_app
        except Exception as e:
            return None

    def track_activity(self):
        current_window = self.get_active_window()
        if current_window != self.active_window:
            self.active_window = current_window
            self.log_activity(current_window)
        self.check_idle_time()

    def log_activity(self, app_name):
        with open("../logs/activity_log.txt", "a") as log_file:
            log_file.write(f"{datetime.now()} - Active Window: {app_name}\n")

    def check_idle_time(self):
        current_time = time.time()
        if self.idle_time_start is None:
            self.idle_time_start = current_time
        elif current_time - self.idle_time_start > self.idle_time_limit:
            self.log_idle_time()

    def log_idle_time(self):
        with open("../logs/activity_log.txt", "a") as log_file:
            log_file.write(f"{datetime.now()} - User is idle\n")
        self.idle_time_start = None
