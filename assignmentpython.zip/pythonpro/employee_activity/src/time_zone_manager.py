import pytz
from datetime import datetime

class TimeZoneManager:
    def __init__(self, time_zone="UTC"):
        self.time_zone = time_zone

    def get_local_time(self):
        local_time_zone = pytz.timezone(self.time_zone)
        return datetime.now(local_time_zone)
