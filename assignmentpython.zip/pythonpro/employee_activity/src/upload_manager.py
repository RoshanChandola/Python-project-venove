from google.cloud import storage
import os

class UploadManager:
    def __init__(self, bucket_name):
        self.client = storage.Client()
        self.bucket = self.client.bucket(bucket_name)

    def upload_file(self, file_path):
        try:
            file_name = os.path.basename(file_path)
            blob = self.bucket.blob(file_name)
            blob.upload_from_filename(file_path)
            print(f"Uploaded {file_name} to Google Cloud Storage bucket {self.bucket.name}")
        except Exception as e:
            print(f"Failed to upload {file_path}: {e}")

    def upload_all_screenshots(self):
        screenshot_folder = "../screenshots"
        for file_name in os.listdir(screenshot_folder):
            file_path = os.path.join(screenshot_folder, file_name)
            self.upload_file(file_path)
